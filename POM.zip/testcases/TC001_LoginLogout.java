package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class TC001_LoginLogout extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setFileName() {
		fileName = "credentials";
	}
	
	@Test(dataProvider="fetchData")
	public void tc001_LoginLogout(String username, String password) {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickLogout();
	}
	
}
