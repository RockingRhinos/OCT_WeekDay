package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class TC001_LoginLogout extends ProjectSpecificMethods{
	
	@Test
	public void tc001_LoginLogout() {
		LoginPage obj = new LoginPage();
		obj.enterUserName()
		.enterPassword()
		.clickLogin()
		.clickLogout();
	}
	
}
