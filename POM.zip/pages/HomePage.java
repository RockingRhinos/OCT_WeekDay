package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {

	public HomePage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(className="decorativeSubmit") WebElement eleLogout;
	public LoginPage clickLogout() {
		eleLogout.click();
//		driver.findElementByClassName("decorativeSubmit").click();
		return new LoginPage();
	}
	
}
