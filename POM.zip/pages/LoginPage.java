package pages;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{
	
	public LoginPage enterUserName() {
		driver.findElementById("username").sendKeys("Demosalesmanager");
//		return new LoginPage();
		/*LoginPage obj = new LoginPage();
		return obj;*/
		return this;
	}
	
	public LoginPage enterPassword() {
		driver.findElementById("password").sendKeys("crmsfa");
		return this;
	}
	
	public HomePage clickLogin() {
		driver.findElementByClassName("decorativeSubmit").click();
		return new HomePage();
	}
	
	
	
	
	
	
	
	
	
	
	

}
