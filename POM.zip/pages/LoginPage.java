package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{
	
	public LoginPage(){
		PageFactory.initElements(driver, this);
	}
	@FindBy(how=How.CLASS_NAME, using="inputLogin") 
	@CacheLookup
	List<WebElement> eleUsername;
	@FindAll({@FindBy(id="password123"), @FindBy(xpath="(//input[@class='inputLogin'])[2]")})
	WebElement elePassword;
	@FindBy(className="decorativeSubmit") 
	WebElement eleLogin;
	public LoginPage enterUserName(String uName) {
		eleUsername.get(0).sendKeys(uName);
		return this;
	}
	public LoginPage enterPassword(String pwd) {
		elePassword.sendKeys(pwd);
		return this;
	}
	public HomePage clickLogin() {
		eleLogin.click();
		return new HomePage();
	}












}
